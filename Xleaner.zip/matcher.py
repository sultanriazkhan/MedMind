"""
matcher.py
==========
Maps an extracted test-name token (from OCR/lab text) to a canonical TestEntry
in the master database.

Matching pipeline (in order of precedence):
  1. Exact alias match         — O(1) dict lookup, confidence = 1.0
  2. Dot-stripped alias match  — removes dots/spaces (e.g. "s.g.p.t" → "sgpt")
  3. LOINC code match          — if token looks like a LOINC code
  4. Token-expansion match     — handles abbreviations like "Hb" → "Hemoglobin"
  5. Fuzzy match (rapidfuzz)   — Levenshtein / partial token matching
  6. No match                  — returns None
"""

import re
from typing import Optional, Tuple
from dataclasses import dataclass

from rapidfuzz import process, fuzz

from test_master_db import (
    TestEntry,
    ALIAS_TO_TEST,
    LOINC_INDEX,
    MASTER_TEST_DB,
)


# ─────────────────────────────────────────────
#  Configuration
# ─────────────────────────────────────────────

# Minimum confidence threshold below which we refuse to report a match
MIN_CONFIDENCE: float = 0.50

# Fuzzy scorer to use (WRatio gives best recall for OCR noise)
FUZZY_SCORER = fuzz.WRatio

# Pre-build a flat list of all alias keys for rapidfuzz lookups
_ALL_ALIASES: list[str] = list(ALIAS_TO_TEST.keys())


# ─────────────────────────────────────────────
#  Data Structures
# ─────────────────────────────────────────────

@dataclass
class MatchResult:
    """Result from the matching pipeline."""
    entry: Optional[TestEntry]      # matched TestEntry, or None if no match
    matched_alias: str              # which alias triggered the match
    match_type: str                 # "exact" | "dotstrip" | "loinc" | "fuzzy" | "none"
    confidence: float               # 0.0 – 1.0


# ─────────────────────────────────────────────
#  Pre-processing helpers
# ─────────────────────────────────────────────

def _normalize_token(token: str) -> str:
    """
    Aggressive normalisation of a raw test-name token:
      - Lowercase
      - Strip leading/trailing whitespace
      - Collapse multiple spaces
      - Strip trailing punctuation
    """
    token = token.lower().strip()
    token = re.sub(r"\s{2,}", " ", token)
    token = re.sub(r"[,;:]+$", "", token)   # trailing punctuation
    return token


def _dot_strip(token: str) -> str:
    """Remove dots and internal spaces — handles abbreviated names like 's.g.p.t'."""
    return re.sub(r"[\s.]+", "", token)


def _looks_like_loinc(token: str) -> bool:
    """Heuristic: LOINC codes have the form NNNNN-N (digits, hyphen, digit)."""
    return bool(re.fullmatch(r"\d{3,5}-\d", token.strip()))


# ─────────────────────────────────────────────
#  Main Matcher Class
# ─────────────────────────────────────────────

class TestMatcher:
    """
    Stateless matcher that converts a raw test-name string into a MatchResult.

    Usage:
        matcher = TestMatcher()
        result = matcher.match("Hb")
        # result.entry.canonical_name  → "Hemoglobin"
        # result.confidence            → 1.0
    """

    def __init__(
        self,
        min_confidence: float = MIN_CONFIDENCE,
        fuzzy_cutoff: float = 70.0,    # rapidfuzz score threshold (0–100)
    ):
        self.min_confidence = min_confidence
        self.fuzzy_cutoff = fuzzy_cutoff

    # ── Public API ────────────────────────────────────────────────────────────

    def match(self, raw_token: str) -> MatchResult:
        """
        Run the full matching pipeline against the master database.

        Args:
            raw_token: A single test-name string from OCR text.

        Returns:
            MatchResult with entry=None if no confident match is found.
        """
        if not raw_token or not raw_token.strip():
            return MatchResult(entry=None, matched_alias="", match_type="none", confidence=0.0)

        norm = _normalize_token(raw_token)

        # 1. Exact alias match
        result = self._exact_match(norm)
        if result:
            return result

        # 2. Dot-strip match (handles "s.g.p.t", "h.b", etc.)
        result = self._dotstrip_match(norm)
        if result:
            return result

        # 3. LOINC code match
        result = self._loinc_match(norm)
        if result:
            return result

        # 4. Fuzzy match
        result = self._fuzzy_match(norm)
        if result and result.confidence >= self.min_confidence:
            return result

        # No match
        return MatchResult(entry=None, matched_alias=norm, match_type="none", confidence=0.0)

    # ── Strategy 1: Exact alias ───────────────────────────────────────────────

    def _exact_match(self, norm: str) -> Optional[MatchResult]:
        """Direct O(1) dictionary lookup."""
        entry = ALIAS_TO_TEST.get(norm)
        if entry:
            return MatchResult(
                entry=entry,
                matched_alias=norm,
                match_type="exact",
                confidence=1.0,
            )
        return None

    # ── Strategy 2: Dot-stripped alias ───────────────────────────────────────

    def _dotstrip_match(self, norm: str) -> Optional[MatchResult]:
        """
        Strip dots and spaces then re-look up.
        Catches: 's.g.p.t' → 'sgpt', 'h.b' → 'hb', 'f.t4' → 'ft4'
        """
        stripped = _dot_strip(norm)
        if stripped == norm:            # no change, skip
            return None
        entry = ALIAS_TO_TEST.get(stripped)
        if entry:
            return MatchResult(
                entry=entry,
                matched_alias=stripped,
                match_type="dotstrip",
                confidence=0.97,
            )
        return None

    # ── Strategy 3: LOINC match ───────────────────────────────────────────────

    def _loinc_match(self, norm: str) -> Optional[MatchResult]:
        """Match by LOINC code if token looks like one."""
        if _looks_like_loinc(norm):
            entry = LOINC_INDEX.get(norm)
            if entry:
                return MatchResult(
                    entry=entry,
                    matched_alias=norm,
                    match_type="loinc",
                    confidence=1.0,
                )
        return None

    # ── Strategy 4: Fuzzy match ───────────────────────────────────────────────

    def _fuzzy_match(self, norm: str) -> Optional[MatchResult]:
        """
        Use rapidfuzz WRatio to find the closest alias.

        Returns None if best score is below fuzzy_cutoff.
        """
        # extractOne returns (match, score, index) or None
        result = process.extractOne(
            norm,
            _ALL_ALIASES,
            scorer=FUZZY_SCORER,
            score_cutoff=self.fuzzy_cutoff,
        )

        if result is None:
            return None

        matched_alias, score, _ = result
        entry = ALIAS_TO_TEST.get(matched_alias)

        if entry is None:
            return None

        # Normalize score from [0, 100] to [0, 1] and scale to [0.5, 0.95]
        confidence = 0.50 + (score / 100.0) * 0.45

        return MatchResult(
            entry=entry,
            matched_alias=matched_alias,
            match_type="fuzzy",
            confidence=round(confidence, 3),
        )


# ─────────────────────────────────────────────
#  Module-level singleton (optional convenience)
# ─────────────────────────────────────────────

_default_matcher = TestMatcher()


def match_test_name(raw_token: str) -> MatchResult:
    """
    Module-level shortcut using the default TestMatcher.

    Example:
        >>> from matcher import match_test_name
        >>> r = match_test_name("HGB")
        >>> r.entry.canonical_name
        'Hemoglobin'
    """
    return _default_matcher.match(raw_token)
