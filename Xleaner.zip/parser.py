"""
parser.py
=========
Extracts structured data from a single candidate lab-report line.

For each line that passes noise filtering, the parser attempts to extract:
  - test_name_token   : the part of the line that appears to be the test name
  - value             : numeric or text result
  - unit              : measurement unit
  - reference_range   : the reference / normal range string

The parser handles the wide variety of formats found in Pakistani / Indian lab
reports, including:

  - "Hb 11.2 g/dL 13-17"
  - "WBC  14000  /uL  4000-11000"
  - "Creatinine: 1.4  mg/dL  (0.7-1.3)"
  - "TSH = 3.5 mIU/L Ref: 0.4-4.0"
  - "ALT/SGPT    45   U/L   10-56  High"
  - "Glucose (Fasting)  98   mg/dL   70-99"
  - "HbA1c % 5.9  < 5.7"
  - "Protein  7.2 g/dL  6.0-8.3 Normal"
"""

import re
from typing import Optional, Tuple
from dataclasses import dataclass


# ─────────────────────────────────────────────
#  Data Structures
# ─────────────────────────────────────────────

@dataclass
class ParsedLine:
    """Result of parsing one candidate line."""
    raw_line: str
    test_name_token: str            # extracted name part (before the value)
    value_raw: str                  # raw string of the result value
    value_numeric: Optional[float]  # parsed float if numeric; None for text results
    unit: str                       # extracted unit
    reference_range: str            # extracted ref range string (e.g. "13-17")
    parse_success: bool             # False → could not extract meaningful fields


# ─────────────────────────────────────────────
#  Regex Building Blocks
# ─────────────────────────────────────────────

# Numeric value — integer, decimal, scientific notation
_NUM = r"[\d]+(?:[.,]\d+)?(?:[eE][+-]?\d+)?"

# Common unit patterns (exhaustive list for South Asian labs)
_UNIT_TOKENS = [
    r"g/dL", r"gm/dL", r"g/dl", r"gm%", r"g%",
    r"mg/dL", r"mg/dl", r"mg%",
    r"ug/dL", r"µg/dL", r"mcg/dL",
    r"ng/mL", r"ng/ml", r"ng/dL", r"ng/L",
    r"pg/mL", r"pg/ml",
    r"nmol/L", r"pmol/L", r"mmol/L", r"µmol/L", r"umol/L",
    r"mEq/L", r"meq/L",
    r"IU/mL", r"mIU/mL", r"mIU/L", r"uIU/mL",
    r"U/L", r"IU/L",
    r"x10\^3/uL", r"10\^3/uL", r"10\^9/L", r"10\^12/L",
    r"K/uL", r"k/uL",
    r"M/uL", r"million/uL",
    r"/uL", r"/ul", r"/cumm", r"cells/uL", r"cells/cumm",
    r"mm/hr", r"mm/h",
    r"fL", r"fl", r"pg",
    r"seconds?", r"sec",
    r"ratio", r"index",
    r"titer", r"titre",
    r"CFU/mL",
    r"kU/L", r"kIU/L",
    r"Todd\s+units?",
    r"mL/min/1\.73m[²2]?", r"mL/min",
    r"%",
    r"mmHg",
]
# Join into alternation, longer tokens first to avoid partial matches
_UNIT_PATTERN = "|".join(sorted(_UNIT_TOKENS, key=len, reverse=True))

# Compiled unit regex
_UNIT_RE = re.compile(
    r"(?<!\w)(" + _UNIT_PATTERN + r")(?!\w)",
    re.IGNORECASE
)

# Reference range patterns:
#   "13-17"  |  "13 - 17"  |  "13–17"  |  "(13-17)"
#   "> 60"   |  "< 0.5"    |  ">=5"
#   "Negative" | "Non-Reactive" | "No Growth"
_RANGE_PATTERNS = [
    # Numeric range: low-high (with optional parentheses/brackets)
    re.compile(
        r"[\(\[]?\s*(" + _NUM + r"\s*[-–to]+\s*" + _NUM + r")\s*[\)\]]?",
        re.IGNORECASE
    ),
    # Greater/less than range
    re.compile(
        r"((?:>=?|<=?|>|<)\s*" + _NUM + r")",
        re.IGNORECASE
    ),
    # Text normal values
    re.compile(
        r"\b(negative|positive|non[\s\-]?reactive|reactive|"
        r"no\s+growth|normal|abnormal|trace|absent)\b",
        re.IGNORECASE
    ),
]

# Flag words that should NOT be treated as result values
_FLAG_WORDS = re.compile(
    r"^(high|low|normal|abnormal|critical|borderline|h|l|n|a|c|\*|"
    r"positive|negative|reactive|non-reactive|elevated|decreased|"
    r"within\s+normal\s+limit[s]?|wnl|wnr)\s*$",
    re.IGNORECASE
)

# Text result values (for qualitative tests)
_TEXT_RESULT_RE = re.compile(
    r"\b(negative|positive|non[\s\-]?reactive|reactive|"
    r"no\s+growth|trace|absent|detected|not\s+detected|"
    r"equivocal|indeterminate)\b",
    re.IGNORECASE
)

# Generic number token (to find the result value)
_VALUE_RE = re.compile(r"\b(\d+(?:[.,]\d+)?(?:[eE][+-]?\d+)?)\b")


# ─────────────────────────────────────────────
#  Line Parser
# ─────────────────────────────────────────────

class LineParser:
    """
    Extracts structured fields from a single cleaned lab-report line.

    Algorithm:
      1. Try to extract unit   → anchors the position of the numeric value
      2. Extract numeric value → the number immediately before or after the unit
      3. Extract ref range     → number pair or text after the value+unit
      4. Extract test name     → the remaining prefix before the value
    """

    # ── Public API ────────────────────────────────────────────────────────────

    def parse(self, line: str) -> ParsedLine:
        """
        Parse a single candidate line.

        Args:
            line: A noise-filtered, OCR-normalized line of text.

        Returns:
            ParsedLine dataclass.
        """
        line = line.strip()

        # ── Step 1: Try to identify a text result (qualitative test) ──────────
        text_match = _TEXT_RESULT_RE.search(line)

        # ── Step 2: Find unit in line ──────────────────────────────────────────
        unit, unit_start, unit_end = self._extract_unit(line)

        # ── Step 3: Extract numeric value ─────────────────────────────────────
        value_raw, value_numeric, value_start, value_end = self._extract_value(
            line, unit_start, unit_end
        )

        # ── Step 4: Extract reference range ───────────────────────────────────
        ref_range = self._extract_ref_range(line, value_end, unit_end)

        # ── Step 5: Extract test name token ───────────────────────────────────
        name_end = min(
            v for v in [value_start, unit_start] if v is not None
        ) if any(v is not None for v in [value_start, unit_start]) else len(line)

        test_name_token = self._clean_name_token(line[:name_end])

        # ── Step 6: Handle text-only results ─────────────────────────────────
        if value_raw is None and text_match:
            value_raw = text_match.group(0)
            value_numeric = None
            # Try to get test name from before the text result
            candidate_name = line[:text_match.start()].strip()
            if candidate_name:
                test_name_token = self._clean_name_token(candidate_name)

        # ── Determine parse success ───────────────────────────────────────────
        parse_success = bool(
            test_name_token and len(test_name_token) >= 2 and value_raw
        )

        return ParsedLine(
            raw_line=line,
            test_name_token=test_name_token,
            value_raw=value_raw or "",
            value_numeric=value_numeric,
            unit=unit,
            reference_range=ref_range,
            parse_success=parse_success,
        )

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _extract_unit(self, line: str) -> Tuple[str, Optional[int], Optional[int]]:
        """
        Find the first unit token in the line.
        Returns (unit_string, start_pos, end_pos) — positions may be None.
        """
        match = _UNIT_RE.search(line)
        if match:
            return match.group(0), match.start(), match.end()
        return "", None, None

    def _extract_value(
        self,
        line: str,
        unit_start: Optional[int],
        unit_end: Optional[int],
    ) -> Tuple[Optional[str], Optional[float], Optional[int], Optional[int]]:
        """
        Find the numeric value.

        Looks for a number:
          - immediately before the unit (most common: "11.2 g/dL")
          - or immediately after test name (if no unit found)

        Returns (raw_string, float_value, start, end).
        """
        # Search all number matches in line
        all_nums = list(_VALUE_RE.finditer(line))

        if not all_nums:
            return None, None, None, None

        best = None

        if unit_start is not None:
            # Prefer the number closest to (and before) the unit
            candidates = [m for m in all_nums if m.end() <= unit_start + 1]
            if candidates:
                best = max(candidates, key=lambda m: m.start())

        if best is None:
            # Fall back: just take the first number in the line
            best = all_nums[0]

        raw = best.group(0).replace(",", ".")   # normalize decimal separator
        try:
            num = float(raw)
        except ValueError:
            num = None

        return raw, num, best.start(), best.end()

    def _extract_ref_range(
        self,
        line: str,
        value_end: Optional[int],
        unit_end: Optional[int],
    ) -> str:
        """
        Extract the reference range from the part of the line after value+unit.
        """
        # Start searching after the unit (or value if no unit)
        search_start = max(
            (pos for pos in [value_end, unit_end] if pos is not None),
            default=0,
        )
        remainder = line[search_start:]

        for pattern in _RANGE_PATTERNS:
            m = pattern.search(remainder)
            if m:
                candidate = m.group(1) if m.lastindex else m.group(0)
                # Don't mistake a flag word for a range
                if not _FLAG_WORDS.match(candidate.strip()):
                    return candidate.strip()

        return ""

    def _clean_name_token(self, raw_name: str) -> str:
        """
        Clean the test name prefix:
          - Strip trailing punctuation, colons, equals signs
          - Collapse whitespace
          - Remove parenthetical suffixes that are not part of the name
        """
        name = raw_name.strip()
        # Remove trailing separators
        name = re.sub(r"[\s:=\-_|]+$", "", name)
        # Remove leading separators
        name = re.sub(r"^[\s:=\-_|]+", "", name)
        # Collapse internal whitespace
        name = re.sub(r"\s{2,}", " ", name)
        # Remove trailing numbers that leaked in (e.g., "Hb 1" → "Hb")
        name = re.sub(r"\s+\d+$", "", name)
        return name.strip()


# ─────────────────────────────────────────────
#  Module-level singleton
# ─────────────────────────────────────────────

_default_parser = LineParser()


def parse_line(line: str) -> ParsedLine:
    """
    Module-level shortcut using the default LineParser.

    Example:
        >>> from parser import parse_line
        >>> r = parse_line("Hb 11.2 g/dL 13-17")
        >>> r.value_numeric, r.unit, r.reference_range
        (11.2, 'g/dL', '13-17')
    """
    return _default_parser.parse(line)
