"""
test_master_db.py
=================
Master database of 100+ common pathology tests used in South Asian (Pakistan/India)
and international lab reports.

Each entry contains:
  - canonical_name    : Standard medical name
  - aliases           : OCR variants, abbreviations, colloquial names
  - loinc_id          : LOINC code (where available)
  - category          : Test panel/category
  - common_units      : Typical units seen in reports
  - value_type        : "numeric" | "text" | "ratio"
  - ref_range         : Default reference range templates keyed by gender/age group
                        Keys: "male", "female", "child", "default"
                        Values: dict with "low" / "high" floats (or None for text)
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any


# ─────────────────────────────────────────────
#  Data Structures
# ─────────────────────────────────────────────

@dataclass
class RefRange:
    """Reference range for a specific demographic."""
    low: Optional[float] = None
    high: Optional[float] = None
    text_normal: Optional[str] = None      # for text-valued tests (e.g., "Negative")
    note: Optional[str] = None             # free-form note (e.g., "age-dependent")


@dataclass
class TestEntry:
    """A single pathology test entry in the master database."""
    canonical_name: str
    aliases: List[str]
    loinc_id: Optional[str]
    category: str
    common_units: List[str]
    value_type: str                         # "numeric" | "text" | "ratio"
    ref_ranges: Dict[str, RefRange] = field(default_factory=dict)
    notes: Optional[str] = None


# ─────────────────────────────────────────────
#  Master Database
# ─────────────────────────────────────────────

MASTER_TEST_DB: List[TestEntry] = [

    # ──────────────── CBC (Complete Blood Count) ────────────────

    TestEntry(
        canonical_name="Hemoglobin",
        aliases=["hb", "hgb", "haemoglobin", "haemoglobine", "hemoglobine",
                 "h.b", "h.g.b", "hgb.", "hb.", "hemo", "haemo"],
        loinc_id="718-7",
        category="CBC",
        common_units=["g/dL", "g/dl", "gm/dl", "gm%", "g%"],
        value_type="numeric",
        ref_ranges={
            "male":   RefRange(low=13.0, high=17.0),
            "female": RefRange(low=12.0, high=16.0),
            "child":  RefRange(low=11.0, high=16.0),
            "default": RefRange(low=12.0, high=17.0),
        }
    ),

    TestEntry(
        canonical_name="WBC Count",
        aliases=["wbc", "tlc", "total leucocyte count", "total leukocyte count",
                 "white blood cells", "white cell count", "leucocytes", "leukocytes",
                 "wcc", "white blood count", "total wbc", "twbc",
                 "t.l.c", "t.w.b.c"],
        loinc_id="6690-2",
        category="CBC",
        common_units=["/uL", "/ul", "cells/uL", "10^3/uL", "K/uL", "x10^3/uL",
                      "/cumm", "cells/cumm", "10^9/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=4000, high=11000),
            "child":   RefRange(low=5000, high=15000),
        }
    ),

    TestEntry(
        canonical_name="RBC Count",
        aliases=["rbc", "red blood cells", "erythrocytes", "red cell count",
                 "r.b.c", "rbc count", "red blood count"],
        loinc_id="789-8",
        category="CBC",
        common_units=["million/uL", "M/uL", "x10^6/uL", "10^6/uL", "10^12/L"],
        value_type="numeric",
        ref_ranges={
            "male":    RefRange(low=4.5, high=5.9),
            "female":  RefRange(low=4.0, high=5.2),
            "child":   RefRange(low=3.8, high=5.5),
            "default": RefRange(low=4.0, high=5.9),
        }
    ),

    TestEntry(
        canonical_name="Platelet Count",
        aliases=["platelets", "plt", "thrombocytes", "platelet", "plts",
                 "platelet count", "p.l.t", "thrombocyte count",
                 "blood platelets", "pl count"],
        loinc_id="777-3",
        category="CBC",
        common_units=["10^3/uL", "K/uL", "/uL", "thousand/uL", "x10^3/uL",
                      "/cumm", "lac/cumm"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=150000, high=450000),
        }
    ),

    TestEntry(
        canonical_name="Hematocrit",
        aliases=["hct", "pcv", "packed cell volume", "haematocrit",
                 "hematocrit value", "crit", "h.c.t", "p.c.v"],
        loinc_id="4544-3",
        category="CBC",
        common_units=["%", "L/L", "fL/fL"],
        value_type="numeric",
        ref_ranges={
            "male":    RefRange(low=40.0, high=54.0),
            "female":  RefRange(low=36.0, high=48.0),
            "default": RefRange(low=36.0, high=54.0),
        }
    ),

    TestEntry(
        canonical_name="MCV",
        aliases=["mcv", "mean corpuscular volume", "mean cell volume",
                 "mean corpusclar volume", "m.c.v"],
        loinc_id="787-2",
        category="CBC",
        common_units=["fL", "fl", "femtoliters"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=80.0, high=100.0),
        }
    ),

    TestEntry(
        canonical_name="MCH",
        aliases=["mch", "mean corpuscular hemoglobin", "mean cell hemoglobin",
                 "mean corpuscular haemoglobin", "m.c.h"],
        loinc_id="785-6",
        category="CBC",
        common_units=["pg", "picograms"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=27.0, high=33.0),
        }
    ),

    TestEntry(
        canonical_name="MCHC",
        aliases=["mchc", "mean corpuscular hemoglobin concentration",
                 "mean cell hemoglobin concentration", "m.c.h.c"],
        loinc_id="786-4",
        category="CBC",
        common_units=["g/dL", "gm/dL", "%"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=32.0, high=36.0),
        }
    ),

    TestEntry(
        canonical_name="RDW",
        aliases=["rdw", "red cell distribution width", "rdw-cv", "rdw-sd",
                 "r.d.w", "red distribution width"],
        loinc_id="788-0",
        category="CBC",
        common_units=["%", "fL"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=11.5, high=14.5),
        }
    ),

    TestEntry(
        canonical_name="Neutrophils",
        aliases=["neutrophils", "neutrophil", "neut", "neutr", "polys",
                 "polymorphonuclear", "pmn", "segs", "segmented neutrophils",
                 "granulocytes", "poly morphs", "n%", "n.%"],
        loinc_id="770-8",
        category="CBC",
        common_units=["%", "/uL", "x10^9/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=40.0, high=75.0, note="percentage"),
        }
    ),

    TestEntry(
        canonical_name="Lymphocytes",
        aliases=["lymphocytes", "lymphocyte", "lymph", "lym", "lymp",
                 "lymphs", "l%", "l.%", "lymphocyte count"],
        loinc_id="736-9",
        category="CBC",
        common_units=["%", "/uL"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=20.0, high=45.0, note="percentage"),
        }
    ),

    TestEntry(
        canonical_name="Monocytes",
        aliases=["monocytes", "monocyte", "mono", "mon", "m%"],
        loinc_id="5905-5",
        category="CBC",
        common_units=["%", "/uL"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=2.0, high=10.0, note="percentage"),
        }
    ),

    TestEntry(
        canonical_name="Eosinophils",
        aliases=["eosinophils", "eosinophil", "eos", "eosin", "eosino",
                 "e%", "eosinophil count"],
        loinc_id="713-8",
        category="CBC",
        common_units=["%", "/uL"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=1.0, high=6.0, note="percentage"),
        }
    ),

    TestEntry(
        canonical_name="Basophils",
        aliases=["basophils", "basophil", "baso", "bas", "b%"],
        loinc_id="706-2",
        category="CBC",
        common_units=["%", "/uL"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=1.0, note="percentage"),
        }
    ),

    TestEntry(
        canonical_name="ESR",
        aliases=["esr", "erythrocyte sedimentation rate", "sed rate",
                 "sedimentation rate", "e.s.r", "westergren", "wintrobe",
                 "erythrocyte sed rate"],
        loinc_id="30341-2",
        category="CBC",
        common_units=["mm/hr", "mm/1hr", "mm/hour"],
        value_type="numeric",
        ref_ranges={
            "male":    RefRange(low=0.0, high=15.0),
            "female":  RefRange(low=0.0, high=20.0),
            "child":   RefRange(low=0.0, high=10.0),
            "default": RefRange(low=0.0, high=20.0),
        }
    ),

    # ──────────────── Inflammation / CRP ────────────────

    TestEntry(
        canonical_name="CRP",
        aliases=["crp", "c-reactive protein", "c reactive protein",
                 "c-rp", "c.r.p", "high sensitivity crp", "hs-crp",
                 "hscrp", "hsCRP", "ultra sensitive crp", "us-crp"],
        loinc_id="1988-5",
        category="Inflammation",
        common_units=["mg/L", "mg/dL", "mg/l"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=5.0),
        }
    ),

    TestEntry(
        canonical_name="Procalcitonin",
        aliases=["pct", "procalcitonin", "pro calcitonin", "pct level"],
        loinc_id="75241-0",
        category="Inflammation",
        common_units=["ng/mL", "ug/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=0.5),
        }
    ),

    # ──────────────── Diabetes ────────────────

    TestEntry(
        canonical_name="Glucose Fasting",
        aliases=["fbs", "fbg", "fasting blood sugar", "fasting glucose",
                 "glucose fasting", "blood glucose fasting", "fpg",
                 "fasting plasma glucose", "f. glucose", "fasting blood glucose",
                 "f.b.s", "f.b.g", "glucose (fasting)", "sugar fasting"],
        loinc_id="1558-6",
        category="Diabetes",
        common_units=["mg/dL", "mg/dl", "mmol/L", "mMol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=70.0, high=99.0),
        }
    ),

    TestEntry(
        canonical_name="Glucose Random",
        aliases=["rbs", "rbs (random)", "random blood sugar", "random glucose",
                 "blood glucose random", "glucose random", "r.b.s",
                 "casual glucose", "blood sugar random"],
        loinc_id="2345-7",
        category="Diabetes",
        common_units=["mg/dL", "mg/dl", "mmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=70.0, high=140.0),
        }
    ),

    TestEntry(
        canonical_name="HbA1c",
        aliases=["hba1c", "hba1c%", "a1c", "glycated hemoglobin",
                 "glycosylated hemoglobin", "glycohemoglobin", "hemoglobin a1c",
                 "haemoglobin a1c", "h.b.a1c", "hb a1c", "hba-1c", "glyh"],
        loinc_id="4548-4",
        category="Diabetes",
        common_units=["%", "mmol/mol"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=4.0, high=5.7),
        }
    ),

    TestEntry(
        canonical_name="Insulin Fasting",
        aliases=["insulin", "fasting insulin", "serum insulin",
                 "insulin level", "s.insulin"],
        loinc_id="20448-7",
        category="Diabetes",
        common_units=["uIU/mL", "mU/L", "pmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=2.0, high=25.0),
        }
    ),

    TestEntry(
        canonical_name="HOMA-IR",
        aliases=["homa ir", "homa-ir", "homeostasis model assessment",
                 "insulin resistance index"],
        loinc_id=None,
        category="Diabetes",
        common_units=["ratio", "index"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=2.5),
        }
    ),

    # ──────────────── Kidney Function ────────────────

    TestEntry(
        canonical_name="Creatinine",
        aliases=["creatinine", "creat", "serum creatinine", "s. creatinine",
                 "s creatinine", "creatinin", "s.creatinine",
                 "creatinine serum", "crtn", "cre"],
        loinc_id="2160-0",
        category="Kidney",
        common_units=["mg/dL", "umol/L", "µmol/L"],
        value_type="numeric",
        ref_ranges={
            "male":    RefRange(low=0.7, high=1.2),
            "female":  RefRange(low=0.5, high=1.0),
            "default": RefRange(low=0.6, high=1.3),
        }
    ),

    TestEntry(
        canonical_name="Blood Urea Nitrogen",
        aliases=["bun", "blood urea nitrogen", "urea nitrogen", "b.u.n"],
        loinc_id="3094-0",
        category="Kidney",
        common_units=["mg/dL", "mmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=7.0, high=25.0),
        }
    ),

    TestEntry(
        canonical_name="Urea",
        aliases=["urea", "blood urea", "serum urea", "s. urea", "s.urea",
                 "urea serum", "su", "urea level"],
        loinc_id="22664-7",
        category="Kidney",
        common_units=["mg/dL", "mmol/L", "mMol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=15.0, high=45.0),
        }
    ),

    TestEntry(
        canonical_name="eGFR",
        aliases=["egfr", "estimated gfr", "glomerular filtration rate",
                 "e.g.f.r", "estimated glomerular filtration rate",
                 "gfr", "gfr estimated"],
        loinc_id="33914-3",
        category="Kidney",
        common_units=["mL/min/1.73m²", "ml/min", "mL/min"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=60.0, high=120.0),
        }
    ),

    TestEntry(
        canonical_name="Uric Acid",
        aliases=["uric acid", "serum uric acid", "s. uric acid",
                 "s.uric acid", "urate", "ua"],
        loinc_id="3084-1",
        category="Kidney",
        common_units=["mg/dL", "umol/L"],
        value_type="numeric",
        ref_ranges={
            "male":    RefRange(low=3.5, high=7.2),
            "female":  RefRange(low=2.6, high=6.0),
            "default": RefRange(low=2.6, high=7.2),
        }
    ),

    TestEntry(
        canonical_name="Cystatin C",
        aliases=["cystatin c", "cystatin-c", "cys c"],
        loinc_id="33863-2",
        category="Kidney",
        common_units=["mg/L", "ng/mL"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.56, high=1.15),
        }
    ),

    # ──────────────── Liver Function ────────────────

    TestEntry(
        canonical_name="ALT",
        aliases=["alt", "sgpt", "s.g.p.t", "alanine aminotransferase",
                 "alanine transaminase", "alanine amino transferase",
                 "alt/sgpt", "sgpt/alt", "s.g.p.t.", "gplt", "gpt",
                 "serum glutamic pyruvic transaminase"],
        loinc_id="1742-6",
        category="Liver",
        common_units=["U/L", "IU/L", "units/L"],
        value_type="numeric",
        ref_ranges={
            "male":    RefRange(low=7.0, high=56.0),
            "female":  RefRange(low=7.0, high=45.0),
            "default": RefRange(low=7.0, high=56.0),
        }
    ),

    TestEntry(
        canonical_name="AST",
        aliases=["ast", "sgot", "s.g.o.t", "aspartate aminotransferase",
                 "aspartate transaminase", "ast/sgot", "sgot/ast",
                 "s.g.o.t.", "got",
                 "serum glutamic oxaloacetic transaminase"],
        loinc_id="1920-8",
        category="Liver",
        common_units=["U/L", "IU/L", "units/L"],
        value_type="numeric",
        ref_ranges={
            "male":    RefRange(low=10.0, high=40.0),
            "female":  RefRange(low=9.0, high=32.0),
            "default": RefRange(low=10.0, high=40.0),
        }
    ),

    TestEntry(
        canonical_name="ALP",
        aliases=["alp", "alkaline phosphatase", "alk phos",
                 "alk. phosphatase", "a.l.p", "alk phosphatase",
                 "serum alkaline phosphatase", "s. alk phos"],
        loinc_id="6768-6",
        category="Liver",
        common_units=["U/L", "IU/L", "units/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=44.0, high=147.0),
        }
    ),

    TestEntry(
        canonical_name="GGT",
        aliases=["ggt", "gamma gt", "gamma-gt", "ggtp",
                 "gamma glutamyl transferase", "gamma glutamyltransferase",
                 "g.g.t"],
        loinc_id="2324-2",
        category="Liver",
        common_units=["U/L", "IU/L"],
        value_type="numeric",
        ref_ranges={
            "male":    RefRange(low=8.0, high=61.0),
            "female":  RefRange(low=5.0, high=36.0),
            "default": RefRange(low=5.0, high=61.0),
        }
    ),

    TestEntry(
        canonical_name="Bilirubin Total",
        aliases=["bilirubin total", "total bilirubin", "bili total",
                 "t. bilirubin", "tbil", "total bili", "serum bilirubin",
                 "s. bilirubin", "bilirubin", "t.bili"],
        loinc_id="1975-2",
        category="Liver",
        common_units=["mg/dL", "umol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.2, high=1.2),
        }
    ),

    TestEntry(
        canonical_name="Bilirubin Direct",
        aliases=["direct bilirubin", "bilirubin direct", "conjugated bilirubin",
                 "d. bilirubin", "dbil", "direct bili"],
        loinc_id="1968-7",
        category="Liver",
        common_units=["mg/dL", "umol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=0.3),
        }
    ),

    TestEntry(
        canonical_name="Bilirubin Indirect",
        aliases=["indirect bilirubin", "bilirubin indirect", "unconjugated bilirubin",
                 "i. bilirubin", "ibil", "indirect bili"],
        loinc_id="1971-1",
        category="Liver",
        common_units=["mg/dL", "umol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.1, high=1.0),
        }
    ),

    TestEntry(
        canonical_name="Albumin",
        aliases=["albumin", "serum albumin", "s. albumin",
                 "alb", "s.alb", "albumin serum"],
        loinc_id="1751-7",
        category="Liver",
        common_units=["g/dL", "g/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=3.5, high=5.0),
        }
    ),

    TestEntry(
        canonical_name="Total Protein",
        aliases=["total protein", "t.protein", "serum total protein",
                 "protein total", "s. protein", "total proteins"],
        loinc_id="2885-2",
        category="Liver",
        common_units=["g/dL", "g/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=6.0, high=8.3),
        }
    ),

    TestEntry(
        canonical_name="Globulin",
        aliases=["globulin", "serum globulin", "total globulin"],
        loinc_id=None,
        category="Liver",
        common_units=["g/dL"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=2.0, high=3.5),
        }
    ),

    TestEntry(
        canonical_name="A/G Ratio",
        aliases=["a/g ratio", "ag ratio", "albumin globulin ratio",
                 "a:g ratio", "a/g"],
        loinc_id=None,
        category="Liver",
        common_units=["ratio"],
        value_type="ratio",
        ref_ranges={
            "default": RefRange(low=1.0, high=2.5),
        }
    ),

    # ──────────────── Lipid Profile ────────────────

    TestEntry(
        canonical_name="Total Cholesterol",
        aliases=["cholesterol", "total cholesterol", "serum cholesterol",
                 "s. cholesterol", "t. cholesterol", "chol",
                 "cholesterol total", "s.chol"],
        loinc_id="2093-3",
        category="Lipid",
        common_units=["mg/dL", "mmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=200.0),
        }
    ),

    TestEntry(
        canonical_name="HDL Cholesterol",
        aliases=["hdl", "hdl cholesterol", "hdl-c", "hdl-cholesterol",
                 "high density lipoprotein", "good cholesterol", "h.d.l",
                 "hdl chol"],
        loinc_id="2085-9",
        category="Lipid",
        common_units=["mg/dL", "mmol/L"],
        value_type="numeric",
        ref_ranges={
            "male":    RefRange(low=40.0, high=60.0),
            "female":  RefRange(low=50.0, high=80.0),
            "default": RefRange(low=40.0, high=80.0),
        }
    ),

    TestEntry(
        canonical_name="LDL Cholesterol",
        aliases=["ldl", "ldl cholesterol", "ldl-c", "ldl-cholesterol",
                 "low density lipoprotein", "bad cholesterol", "l.d.l",
                 "ldl chol"],
        loinc_id="2089-1",
        category="Lipid",
        common_units=["mg/dL", "mmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=100.0),
        }
    ),

    TestEntry(
        canonical_name="Triglycerides",
        aliases=["triglycerides", "tg", "trig", "trigs", "triglyceride",
                 "serum triglycerides", "s. tg", "trigl", "tgl",
                 "trigly", "t.g"],
        loinc_id="2571-8",
        category="Lipid",
        common_units=["mg/dL", "mmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=150.0),
        }
    ),

    TestEntry(
        canonical_name="VLDL Cholesterol",
        aliases=["vldl", "vldl cholesterol", "vldl-c",
                 "very low density lipoprotein"],
        loinc_id="13457-7",
        category="Lipid",
        common_units=["mg/dL", "mmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=2.0, high=30.0),
        }
    ),

    # ──────────────── Thyroid ────────────────

    TestEntry(
        canonical_name="TSH",
        aliases=["tsh", "thyroid stimulating hormone", "thyrotropin",
                 "t.s.h", "tsh level", "serum tsh", "s.tsh"],
        loinc_id="3016-3",
        category="Thyroid",
        common_units=["mIU/L", "uIU/mL", "mlU/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.4, high=4.0),
        }
    ),

    TestEntry(
        canonical_name="Free T3",
        aliases=["ft3", "free t3", "free triiodothyronine", "ft-3",
                 "f.t3", "free t-3", "freeT3"],
        loinc_id="3051-0",
        category="Thyroid",
        common_units=["pg/mL", "pmol/L", "ng/dL"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=2.3, high=4.2),
        }
    ),

    TestEntry(
        canonical_name="Free T4",
        aliases=["ft4", "free t4", "free thyroxine", "ft-4",
                 "f.t4", "free t-4", "freeT4"],
        loinc_id="3024-7",
        category="Thyroid",
        common_units=["ng/dL", "pmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.8, high=1.8),
        }
    ),

    TestEntry(
        canonical_name="Total T3",
        aliases=["t3", "total t3", "triiodothyronine", "t-3",
                 "serum t3", "s.t3"],
        loinc_id="3053-6",
        category="Thyroid",
        common_units=["ng/dL", "nmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=80.0, high=200.0),
        }
    ),

    TestEntry(
        canonical_name="Total T4",
        aliases=["t4", "total t4", "thyroxine", "t-4",
                 "serum t4", "s.t4"],
        loinc_id="3025-4",
        category="Thyroid",
        common_units=["ug/dL", "nmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=5.0, high=12.0),
        }
    ),

    TestEntry(
        canonical_name="Anti-TPO",
        aliases=["anti-tpo", "anti tpo", "tpo antibody", "thyroid peroxidase antibody",
                 "tpoab", "anti-thyroid peroxidase"],
        loinc_id="8098-6",
        category="Thyroid",
        common_units=["IU/mL", "kIU/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=34.0),
        }
    ),

    # ──────────────── Electrolytes ────────────────

    TestEntry(
        canonical_name="Sodium",
        aliases=["sodium", "na", "serum sodium", "s. sodium",
                 "s.sodium", "na+", "na level"],
        loinc_id="2951-2",
        category="Electrolytes",
        common_units=["mEq/L", "mmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=136.0, high=145.0),
        }
    ),

    TestEntry(
        canonical_name="Potassium",
        aliases=["potassium", "k", "serum potassium", "s. potassium",
                 "s.potassium", "k+", "k level"],
        loinc_id="2823-3",
        category="Electrolytes",
        common_units=["mEq/L", "mmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=3.5, high=5.0),
        }
    ),

    TestEntry(
        canonical_name="Chloride",
        aliases=["chloride", "cl", "serum chloride", "s. chloride",
                 "cl-", "chloride serum"],
        loinc_id="2075-0",
        category="Electrolytes",
        common_units=["mEq/L", "mmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=98.0, high=106.0),
        }
    ),

    TestEntry(
        canonical_name="Calcium",
        aliases=["calcium", "ca", "serum calcium", "s. calcium",
                 "s.calcium", "ca2+", "total calcium"],
        loinc_id="17861-6",
        category="Electrolytes",
        common_units=["mg/dL", "mmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=8.5, high=10.5),
        }
    ),

    TestEntry(
        canonical_name="Phosphorus",
        aliases=["phosphorus", "phosphate", "serum phosphorus", "s. phosphorus",
                 "phos", "inorganic phosphate"],
        loinc_id="2777-1",
        category="Electrolytes",
        common_units=["mg/dL", "mmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=2.5, high=4.5),
        }
    ),

    TestEntry(
        canonical_name="Magnesium",
        aliases=["magnesium", "mg", "serum magnesium", "s. magnesium",
                 "mg level"],
        loinc_id="19123-9",
        category="Electrolytes",
        common_units=["mEq/L", "mg/dL", "mmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=1.7, high=2.2),
        }
    ),

    TestEntry(
        canonical_name="Bicarbonate",
        aliases=["bicarbonate", "hco3", "co2", "total co2", "hco3-",
                 "serum bicarbonate", "bicarb"],
        loinc_id="1963-8",
        category="Electrolytes",
        common_units=["mEq/L", "mmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=22.0, high=29.0),
        }
    ),

    # ──────────────── Vitamins / Minerals ────────────────

    TestEntry(
        canonical_name="Vitamin D",
        aliases=["vitamin d", "vit d", "vit. d", "25-oh vitamin d",
                 "25-hydroxyvitamin d", "25 oh vit d", "25ohd",
                 "vitamin d total", "vit d total", "vit d3",
                 "calcidiol", "25(oh)d"],
        loinc_id="35365-6",
        category="Vitamins",
        common_units=["ng/mL", "nmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=30.0, high=100.0),
        }
    ),

    TestEntry(
        canonical_name="Vitamin B12",
        aliases=["vitamin b12", "vit b12", "cobalamin", "b12",
                 "vit. b12", "cyanocobalamin", "b-12"],
        loinc_id="2132-9",
        category="Vitamins",
        common_units=["pg/mL", "pmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=200.0, high=900.0),
        }
    ),

    TestEntry(
        canonical_name="Folate",
        aliases=["folate", "folic acid", "serum folate", "folic acid level",
                 "vitamin b9", "vit b9", "b9"],
        loinc_id="2132-9",
        category="Vitamins",
        common_units=["ng/mL", "nmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=3.0, high=17.0),
        }
    ),

    # ──────────────── Iron Studies ────────────────

    TestEntry(
        canonical_name="Serum Iron",
        aliases=["iron", "serum iron", "s. iron", "s.iron",
                 "fe", "iron level", "total iron"],
        loinc_id="2498-4",
        category="Iron Studies",
        common_units=["ug/dL", "umol/L"],
        value_type="numeric",
        ref_ranges={
            "male":    RefRange(low=65.0, high=175.0),
            "female":  RefRange(low=50.0, high=170.0),
            "default": RefRange(low=50.0, high=175.0),
        }
    ),

    TestEntry(
        canonical_name="Ferritin",
        aliases=["ferritin", "serum ferritin", "s. ferritin",
                 "s.ferritin", "ferritin level"],
        loinc_id="2276-4",
        category="Iron Studies",
        common_units=["ng/mL", "ug/L"],
        value_type="numeric",
        ref_ranges={
            "male":    RefRange(low=20.0, high=250.0),
            "female":  RefRange(low=10.0, high=120.0),
            "default": RefRange(low=10.0, high=250.0),
        }
    ),

    TestEntry(
        canonical_name="TIBC",
        aliases=["tibc", "total iron binding capacity",
                 "iron binding capacity", "t.i.b.c"],
        loinc_id="2501-5",
        category="Iron Studies",
        common_units=["ug/dL", "umol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=250.0, high=370.0),
        }
    ),

    TestEntry(
        canonical_name="Transferrin Saturation",
        aliases=["transferrin saturation", "tsat", "iron saturation",
                 "sat %", "% saturation", "transferrin sat"],
        loinc_id="2502-3",
        category="Iron Studies",
        common_units=["%"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=20.0, high=50.0),
        }
    ),

    # ──────────────── Cardiac Markers ────────────────

    TestEntry(
        canonical_name="Troponin I",
        aliases=["troponin i", "troponin-i", "ctni", "cardiac troponin i",
                 "hs troponin i", "high sensitivity troponin i", "trop i",
                 "tropi"],
        loinc_id="10839-9",
        category="Cardiac",
        common_units=["ng/mL", "ug/L", "ng/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=0.04),
        }
    ),

    TestEntry(
        canonical_name="Troponin T",
        aliases=["troponin t", "troponin-t", "ctnt", "cardiac troponin t",
                 "hs troponin t", "high sensitivity troponin t", "trop t"],
        loinc_id="6598-7",
        category="Cardiac",
        common_units=["ng/mL", "ug/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=0.01),
        }
    ),

    TestEntry(
        canonical_name="CK-MB",
        aliases=["ck-mb", "ckmb", "creatine kinase mb", "ck mb",
                 "c.k-m.b", "creatine kinase myocardial band"],
        loinc_id="13969-1",
        category="Cardiac",
        common_units=["U/L", "ng/mL"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=25.0),
        }
    ),

    TestEntry(
        canonical_name="CK Total",
        aliases=["ck", "cpk", "creatine kinase", "total ck",
                 "creatine phosphokinase", "c.k", "c.p.k"],
        loinc_id="2157-6",
        category="Cardiac",
        common_units=["U/L", "IU/L"],
        value_type="numeric",
        ref_ranges={
            "male":    RefRange(low=39.0, high=308.0),
            "female":  RefRange(low=26.0, high=192.0),
            "default": RefRange(low=26.0, high=308.0),
        }
    ),

    TestEntry(
        canonical_name="LDH",
        aliases=["ldh", "lactate dehydrogenase", "lactic dehydrogenase",
                 "l.d.h", "ldh total"],
        loinc_id="14804-9",
        category="Cardiac",
        common_units=["U/L", "IU/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=140.0, high=280.0),
        }
    ),

    TestEntry(
        canonical_name="D-Dimer",
        aliases=["d-dimer", "d dimer", "ddimer", "fibrin degradation products",
                 "fdp", "d.dimer"],
        loinc_id="48065-7",
        category="Cardiac",
        common_units=["ug/mL", "mg/L", "ng/mL", "ug/L FEU"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=0.5),
        }
    ),

    TestEntry(
        canonical_name="BNP",
        aliases=["bnp", "brain natriuretic peptide", "b-type natriuretic peptide",
                 "n-terminal pro bnp", "nt-probnp", "pro-bnp"],
        loinc_id="30934-4",
        category="Cardiac",
        common_units=["pg/mL"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=100.0),
        }
    ),

    TestEntry(
        canonical_name="Myoglobin",
        aliases=["myoglobin", "myoglobine", "serum myoglobin"],
        loinc_id="4005-5",
        category="Cardiac",
        common_units=["ng/mL", "ug/L"],
        value_type="numeric",
        ref_ranges={
            "male":    RefRange(low=28.0, high=72.0),
            "female":  RefRange(low=25.0, high=58.0),
            "default": RefRange(low=25.0, high=72.0),
        }
    ),

    # ──────────────── Hormones ────────────────

    TestEntry(
        canonical_name="PSA",
        aliases=["psa", "prostate specific antigen", "total psa",
                 "p.s.a", "prostate antigen"],
        loinc_id="2857-1",
        category="Hormones",
        common_units=["ng/mL", "ug/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=4.0),
        }
    ),

    TestEntry(
        canonical_name="Beta hCG",
        aliases=["beta hcg", "b-hcg", "bhcg", "human chorionic gonadotropin",
                 "hcg", "b.hcg", "beta-hcg", "serum hcg"],
        loinc_id="19080-1",
        category="Hormones",
        common_units=["mIU/mL", "IU/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=5.0, note="non-pregnant"),
        }
    ),

    TestEntry(
        canonical_name="LH",
        aliases=["lh", "luteinizing hormone", "lutenizing hormone",
                 "l.h", "lh level"],
        loinc_id="10501-5",
        category="Hormones",
        common_units=["mIU/mL", "IU/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=1.0, high=20.0),
        }
    ),

    TestEntry(
        canonical_name="FSH",
        aliases=["fsh", "follicle stimulating hormone", "follicular stimulating hormone",
                 "f.s.h", "fsh level"],
        loinc_id="15067-2",
        category="Hormones",
        common_units=["mIU/mL", "IU/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=1.0, high=26.0),
        }
    ),

    TestEntry(
        canonical_name="Prolactin",
        aliases=["prolactin", "prl", "serum prolactin", "prolactin level"],
        loinc_id="10334-1",
        category="Hormones",
        common_units=["ng/mL", "mIU/L", "mIU/mL"],
        value_type="numeric",
        ref_ranges={
            "male":    RefRange(low=2.0, high=18.0),
            "female":  RefRange(low=2.0, high=29.0),
            "default": RefRange(low=2.0, high=29.0),
        }
    ),

    TestEntry(
        canonical_name="Testosterone Total",
        aliases=["testosterone", "total testosterone", "serum testosterone",
                 "test level", "testosterone total"],
        loinc_id="2986-8",
        category="Hormones",
        common_units=["ng/dL", "nmol/L"],
        value_type="numeric",
        ref_ranges={
            "male":    RefRange(low=300.0, high=1000.0),
            "female":  RefRange(low=15.0, high=70.0),
            "default": RefRange(low=15.0, high=1000.0),
        }
    ),

    TestEntry(
        canonical_name="Estradiol",
        aliases=["estradiol", "e2", "oestradiol", "estrogen",
                 "estradiol e2", "serum estradiol"],
        loinc_id="2243-4",
        category="Hormones",
        common_units=["pg/mL", "pmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=15.0, high=350.0),
        }
    ),

    TestEntry(
        canonical_name="Progesterone",
        aliases=["progesterone", "serum progesterone", "progesterone level"],
        loinc_id="2839-9",
        category="Hormones",
        common_units=["ng/mL", "nmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.1, high=25.0),
        }
    ),

    TestEntry(
        canonical_name="Cortisol",
        aliases=["cortisol", "serum cortisol", "cortisol am",
                 "morning cortisol", "8 am cortisol"],
        loinc_id="2143-6",
        category="Hormones",
        common_units=["ug/dL", "nmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=6.0, high=23.0, note="AM sample"),
        }
    ),

    TestEntry(
        canonical_name="DHEA-S",
        aliases=["dhea-s", "dheas", "dehydroepiandrosterone sulfate",
                 "dhea sulfate", "d.h.e.a-s"],
        loinc_id="2191-3",
        category="Hormones",
        common_units=["ug/dL", "umol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=80.0, high=560.0),
        }
    ),

    TestEntry(
        canonical_name="Insulin-like Growth Factor 1",
        aliases=["igf-1", "igf1", "somatomedin c", "igf 1",
                 "insulin like growth factor"],
        loinc_id="10139-1",
        category="Hormones",
        common_units=["ng/mL", "nmol/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=100.0, high=300.0),
        }
    ),

    # ──────────────── Coagulation ────────────────

    TestEntry(
        canonical_name="PT",
        aliases=["pt", "prothrombin time", "pro time", "p.t",
                 "p.t.", "prothrombin time (pt)"],
        loinc_id="5902-2",
        category="Coagulation",
        common_units=["seconds", "sec", "s"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=11.0, high=13.5),
        }
    ),

    TestEntry(
        canonical_name="INR",
        aliases=["inr", "international normalized ratio", "i.n.r",
                 "pt-inr", "pt/inr"],
        loinc_id="6301-6",
        category="Coagulation",
        common_units=["ratio", ""],
        value_type="ratio",
        ref_ranges={
            "default": RefRange(low=0.8, high=1.2),
        }
    ),

    TestEntry(
        canonical_name="APTT",
        aliases=["aptt", "ptt", "activated partial thromboplastin time",
                 "partial thromboplastin time", "a.p.t.t"],
        loinc_id="3173-2",
        category="Coagulation",
        common_units=["seconds", "sec"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=25.0, high=35.0),
        }
    ),

    TestEntry(
        canonical_name="Fibrinogen",
        aliases=["fibrinogen", "serum fibrinogen", "plasma fibrinogen"],
        loinc_id="3255-7",
        category="Coagulation",
        common_units=["mg/dL", "g/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=200.0, high=400.0),
        }
    ),

    # ──────────────── Urinalysis ────────────────

    TestEntry(
        canonical_name="Urine pH",
        aliases=["urine ph", "ph urine", "urine reaction",
                 "reaction (ph)", "urinary ph"],
        loinc_id="5764-6",
        category="Urine",
        common_units=[""],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=4.5, high=8.5),
        }
    ),

    TestEntry(
        canonical_name="Urine Specific Gravity",
        aliases=["specific gravity", "sp. gravity", "sg", "s.g",
                 "urine sg", "urine specific gravity", "spec gravity"],
        loinc_id="5811-5",
        category="Urine",
        common_units=[""],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=1.001, high=1.030),
        }
    ),

    TestEntry(
        canonical_name="Urine Protein",
        aliases=["urine protein", "protein urine", "urine albumin",
                 "proteinuria", "albuminuria", "urine alb"],
        loinc_id="5804-0",
        category="Urine",
        common_units=["mg/dL", "mg/24h", "+", "++"],
        value_type="text",
        ref_ranges={
            "default": RefRange(text_normal="Negative"),
        }
    ),

    TestEntry(
        canonical_name="Urine Glucose",
        aliases=["urine glucose", "glucose urine", "urine sugar", "glycosuria"],
        loinc_id="25428-4",
        category="Urine",
        common_units=["mg/dL", "+"],
        value_type="text",
        ref_ranges={
            "default": RefRange(text_normal="Negative"),
        }
    ),

    TestEntry(
        canonical_name="Microalbumin",
        aliases=["microalbumin", "microalbuminuria", "urine microalbumin",
                 "micro albumin", "ma/cr ratio"],
        loinc_id="14957-5",
        category="Urine",
        common_units=["mg/L", "mg/24h", "ug/mg"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=30.0),
        }
    ),

    TestEntry(
        canonical_name="Urine Creatinine",
        aliases=["urine creatinine", "creatinine urine", "24hr urine creatinine",
                 "urinary creatinine"],
        loinc_id="2161-8",
        category="Urine",
        common_units=["mg/dL", "mg/24h", "mmol/24h"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=20.0, high=320.0),
        }
    ),

    # ──────────────── Infectious Disease ────────────────

    TestEntry(
        canonical_name="Hepatitis B Surface Antigen",
        aliases=["hbsag", "hbs ag", "hbs antigen", "hepatitis b surface antigen",
                 "hep b surface ag", "h.b.s.ag", "hbsag (qualitative)"],
        loinc_id="5196-1",
        category="Infectious Disease",
        common_units=[""],
        value_type="text",
        ref_ranges={
            "default": RefRange(text_normal="Non-Reactive"),
        }
    ),

    TestEntry(
        canonical_name="Anti-HCV",
        aliases=["anti-hcv", "hcv antibody", "hepatitis c antibody",
                 "anti hcv", "hep c antibody", "hcv ab"],
        loinc_id="16128-1",
        category="Infectious Disease",
        common_units=[""],
        value_type="text",
        ref_ranges={
            "default": RefRange(text_normal="Non-Reactive"),
        }
    ),

    TestEntry(
        canonical_name="HIV Antigen/Antibody",
        aliases=["hiv", "hiv 1/2", "hiv antigen antibody", "anti-hiv",
                 "hiv ag/ab", "4th gen hiv", "hiv combo"],
        loinc_id="75622-1",
        category="Infectious Disease",
        common_units=[""],
        value_type="text",
        ref_ranges={
            "default": RefRange(text_normal="Non-Reactive"),
        }
    ),

    TestEntry(
        canonical_name="Dengue NS1 Antigen",
        aliases=["dengue ns1", "ns1 antigen", "dengue ns1 ag",
                 "dengue antigen"],
        loinc_id="29660-7",
        category="Infectious Disease",
        common_units=[""],
        value_type="text",
        ref_ranges={
            "default": RefRange(text_normal="Negative"),
        }
    ),

    TestEntry(
        canonical_name="Dengue IgM",
        aliases=["dengue igm", "dengue igg", "dengue antibody",
                 "dengue serology"],
        loinc_id="25338-5",
        category="Infectious Disease",
        common_units=[""],
        value_type="text",
        ref_ranges={
            "default": RefRange(text_normal="Negative"),
        }
    ),

    TestEntry(
        canonical_name="Typhoid IgM",
        aliases=["typhoid igm", "typhidot igm", "typhoid antibody",
                 "salmonella igm", "widal test"],
        loinc_id=None,
        category="Infectious Disease",
        common_units=["titer"],
        value_type="text",
        ref_ranges={
            "default": RefRange(text_normal="Negative"),
        }
    ),

    TestEntry(
        canonical_name="Malaria Antigen",
        aliases=["malaria", "malaria antigen", "malaria rdt",
                 "malaria parasite", "mp"],
        loinc_id=None,
        category="Infectious Disease",
        common_units=[""],
        value_type="text",
        ref_ranges={
            "default": RefRange(text_normal="Negative"),
        }
    ),

    # ──────────────── Autoimmune / Rheumatology ────────────────

    TestEntry(
        canonical_name="ANA",
        aliases=["ana", "antinuclear antibody", "antinuclear antibodies",
                 "anti-nuclear antibody", "a.n.a"],
        loinc_id="4542-7",
        category="Autoimmune",
        common_units=["titer", "ratio"],
        value_type="text",
        ref_ranges={
            "default": RefRange(text_normal="Negative"),
        }
    ),

    TestEntry(
        canonical_name="Rheumatoid Factor",
        aliases=["rf", "rheumatoid factor", "r.f", "ra factor",
                 "r.a factor", "rheumatoid arthritis factor"],
        loinc_id="4537-7",
        category="Autoimmune",
        common_units=["IU/mL", "U/mL"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=20.0),
        }
    ),

    TestEntry(
        canonical_name="Anti-dsDNA",
        aliases=["anti-dsdna", "anti dsdna", "anti double stranded dna",
                 "ds dna antibody", "ds-dna"],
        loinc_id="5119-3",
        category="Autoimmune",
        common_units=["IU/mL", "U/mL"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=30.0),
        }
    ),

    TestEntry(
        canonical_name="ASO Titre",
        aliases=["aso", "asot", "antistreptolysin o", "anti streptolysin o",
                 "a.s.o", "aso titre", "aso titer"],
        loinc_id="5384-2",
        category="Autoimmune",
        common_units=["IU/mL", "Todd units"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=200.0),
        }
    ),

    # ──────────────── Pancreas ────────────────

    TestEntry(
        canonical_name="Amylase",
        aliases=["amylase", "serum amylase", "s. amylase",
                 "alpha amylase"],
        loinc_id="1798-8",
        category="Pancreas",
        common_units=["U/L", "IU/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=30.0, high=110.0),
        }
    ),

    TestEntry(
        canonical_name="Lipase",
        aliases=["lipase", "serum lipase", "s. lipase"],
        loinc_id="3040-5",
        category="Pancreas",
        common_units=["U/L", "IU/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=160.0),
        }
    ),

    # ──────────────── Cancer Markers ────────────────

    TestEntry(
        canonical_name="CEA",
        aliases=["cea", "carcinoembryonic antigen", "carcinoma embryonic antigen"],
        loinc_id="2857-1",
        category="Cancer Markers",
        common_units=["ng/mL", "ug/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=5.0),
        }
    ),

    TestEntry(
        canonical_name="CA 125",
        aliases=["ca 125", "ca-125", "cancer antigen 125", "ca125"],
        loinc_id="10334-1",
        category="Cancer Markers",
        common_units=["U/mL", "kU/L"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=35.0),
        }
    ),

    TestEntry(
        canonical_name="CA 19-9",
        aliases=["ca 19-9", "ca-19-9", "cancer antigen 19-9", "ca19-9"],
        loinc_id="24108-3",
        category="Cancer Markers",
        common_units=["U/mL"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=37.0),
        }
    ),

    TestEntry(
        canonical_name="AFP",
        aliases=["afp", "alpha fetoprotein", "alpha-fetoprotein",
                 "alpha feto protein"],
        loinc_id="1834-1",
        category="Cancer Markers",
        common_units=["ng/mL", "IU/mL"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=10.0),
        }
    ),

    # ──────────────── Miscellaneous / Special Tests ────────────────

    TestEntry(
        canonical_name="Blood Culture",
        aliases=["blood culture", "bld culture", "culture blood",
                 "aerobic culture", "anaerobic culture"],
        loinc_id="600-7",
        category="Microbiology",
        common_units=[""],
        value_type="text",
        ref_ranges={
            "default": RefRange(text_normal="No Growth"),
        }
    ),

    TestEntry(
        canonical_name="Urine Culture",
        aliases=["urine culture", "urine c&s", "urine c/s",
                 "culture urine", "c&s urine", "mid-stream urine culture"],
        loinc_id="630-4",
        category="Microbiology",
        common_units=["CFU/mL"],
        value_type="text",
        ref_ranges={
            "default": RefRange(text_normal="No Growth"),
        }
    ),

    TestEntry(
        canonical_name="Stool Culture",
        aliases=["stool culture", "stool c&s", "stool microscopy",
                 "feces culture", "culture stool"],
        loinc_id="625-4",
        category="Microbiology",
        common_units=[""],
        value_type="text",
        ref_ranges={
            "default": RefRange(text_normal="No Growth"),
        }
    ),

    TestEntry(
        canonical_name="Mantoux Test",
        aliases=["mantoux", "tuberculin test", "ppd", "tb test",
                 "tuberculin skin test", "tst"],
        loinc_id=None,
        category="Microbiology",
        common_units=["mm"],
        value_type="numeric",
        ref_ranges={
            "default": RefRange(low=0.0, high=5.0),
        }
    ),

    TestEntry(
        canonical_name="Stool Occult Blood",
        aliases=["occult blood", "fobt", "stool occult", "fecal occult blood",
                 "hidden blood stool", "guaiac test"],
        loinc_id="2335-8",
        category="GI",
        common_units=[""],
        value_type="text",
        ref_ranges={
            "default": RefRange(text_normal="Negative"),
        }
    ),

    TestEntry(
        canonical_name="H. pylori Antigen",
        aliases=["h pylori", "h. pylori", "helicobacter pylori",
                 "h pylori antigen", "hp antigen", "h. pylori ag"],
        loinc_id="13334-8",
        category="GI",
        common_units=[""],
        value_type="text",
        ref_ranges={
            "default": RefRange(text_normal="Negative"),
        }
    ),

]


# ─────────────────────────────────────────────
#  Convenience Lookup Structures (built at import)
# ─────────────────────────────────────────────

# Flat alias → TestEntry lookup for O(1) exact matching
ALIAS_TO_TEST: dict[str, TestEntry] = {}
for _entry in MASTER_TEST_DB:
    # Index canonical name itself (lowercased + stripped)
    ALIAS_TO_TEST[_entry.canonical_name.lower().strip()] = _entry
    for _alias in _entry.aliases:
        ALIAS_TO_TEST[_alias.lower().strip()] = _entry

# Category → list of tests
CATEGORY_INDEX: dict[str, list[TestEntry]] = {}
for _entry in MASTER_TEST_DB:
    CATEGORY_INDEX.setdefault(_entry.category, []).append(_entry)

# LOINC → TestEntry
LOINC_INDEX: dict[str, TestEntry] = {
    e.loinc_id: e for e in MASTER_TEST_DB if e.loinc_id
}
