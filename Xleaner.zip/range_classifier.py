"""
range_classifier.py
===================
Determines the clinical flag (High / Low / Normal / Critical / Unknown)
for a test result.

Priority order for reference range:
  1. Use extracted ref range from the report line (most accurate — lab-specific)
  2. Fall back to master database reference range (gender/age-matched if possible)
  3. If neither available → flag = "Unknown"
"""

import re
from typing import Optional, Tuple
from enum import Enum

from test_master_db import TestEntry, RefRange


# ─────────────────────────────────────────────
#  Flag Enum
# ─────────────────────────────────────────────

class Flag(str, Enum):
    HIGH        = "High"
    LOW         = "Low"
    NORMAL      = "Normal"
    CRITICAL_H  = "Critical High"
    CRITICAL_L  = "Critical Low"
    UNKNOWN     = "Unknown"
    TEXT_NORMAL = "Normal"          # for text-valued tests (Negative, Non-Reactive)
    TEXT_ABNORMAL = "Abnormal"


# ─────────────────────────────────────────────
#  Text result classifiers
# ─────────────────────────────────────────────

_NORMAL_TEXT_VALUES = re.compile(
    r"^(negative|non[\s\-]?reactive|no\s+growth|normal|absent|"
    r"not\s+detected|within\s+normal\s+limits?|wnl)\s*$",
    re.IGNORECASE
)

_ABNORMAL_TEXT_VALUES = re.compile(
    r"^(positive|reactive|detected|abnormal|trace|equivocal)\s*$",
    re.IGNORECASE
)


# ─────────────────────────────────────────────
#  Numeric range parsers
# ─────────────────────────────────────────────

_NUM = r"[\d]+(?:[.,]\d+)?"

# "10-20", "10 - 20", "10–20", "10 to 20"
_RANGE_RE = re.compile(
    r"(" + _NUM + r")\s*[-–to]+\s*(" + _NUM + r")",
    re.IGNORECASE
)

# "> 60", ">=5", "< 0.5"
_BOUND_RE = re.compile(
    r"(>=?|<=?)\s*(" + _NUM + r")",
    re.IGNORECASE
)


def _parse_numeric_range(range_str: str) -> Tuple[Optional[float], Optional[float]]:
    """
    Parse a reference range string into (low, high) floats.
    Returns (None, None) if parsing fails.
    """
    if not range_str:
        return None, None

    # Normalize decimal separators
    range_str = range_str.replace(",", ".")

    # Try "low - high" format
    m = _RANGE_RE.search(range_str)
    if m:
        try:
            return float(m.group(1)), float(m.group(2))
        except ValueError:
            pass

    # Try "> N" or "< N" format
    m = _BOUND_RE.search(range_str)
    if m:
        op, val = m.group(1), float(m.group(2))
        if op in (">", ">="):
            return val, None   # only lower bound known
        elif op in ("<", "<="):
            return None, val   # only upper bound known

    return None, None


# ─────────────────────────────────────────────
#  Critical value thresholds (panic values)
#  Based on commonly used lab critical alert ranges
# ─────────────────────────────────────────────

# {canonical_name_lower: (critical_low, critical_high)}
CRITICAL_THRESHOLDS: dict[str, Tuple[Optional[float], Optional[float]]] = {
    "hemoglobin":          (7.0, 20.0),
    "wbc count":           (2000.0, 30000.0),
    "platelet count":      (50000.0, 1000000.0),
    "glucose fasting":     (45.0, 500.0),
    "glucose random":      (45.0, 500.0),
    "sodium":              (120.0, 160.0),
    "potassium":           (2.5, 6.5),
    "calcium":             (6.5, 13.0),
    "creatinine":          (None, 10.0),
    "troponin i":          (None, 2.0),
    "troponin t":          (None, 2.0),
    "inr":                 (None, 5.0),
    "pt":                  (None, 40.0),
    "d-dimer":             (None, 10.0),
}


# ─────────────────────────────────────────────
#  Main Classifier
# ─────────────────────────────────────────────

class RangeClassifier:
    """
    Classifies a test result value against its reference range.

    Usage:
        clf = RangeClassifier()
        flag = clf.classify(
            entry=entry,
            value_numeric=11.2,
            value_text="",
            extracted_range="13-17",
            gender="male",
        )
        # → Flag.LOW
    """

    # ── Public API ────────────────────────────────────────────────────────────

    def classify(
        self,
        entry: Optional[TestEntry],
        value_numeric: Optional[float],
        value_text: str,
        extracted_range: str = "",
        gender: str = "default",         # "male" | "female" | "child" | "default"
    ) -> Tuple[str, str]:
        """
        Classify a result and return (flag_string, effective_range_string).

        Args:
            entry           : Matched TestEntry (None if unmatched)
            value_numeric   : Parsed float value (None for text results)
            value_text      : Raw value string (used for text-type results)
            extracted_range : Ref range string extracted from the report line
            gender          : Patient gender for demographic-matched ranges

        Returns:
            (flag, effective_range)
            flag            : e.g. "High", "Low", "Normal", "Unknown"
            effective_range : The range string actually used for classification
        """

        # ── Text-valued test ──────────────────────────────────────────────────
        if entry and entry.value_type == "text":
            return self._classify_text(value_text, entry, extracted_range)

        # ── Numeric-valued test ───────────────────────────────────────────────
        if value_numeric is not None:
            return self._classify_numeric(
                value_numeric, entry, extracted_range, gender
            )

        # If we have extracted text that looks like a result but no numeric
        if value_text:
            return self._classify_text(value_text, entry, extracted_range)

        return Flag.UNKNOWN, extracted_range

    # ── Text classification ───────────────────────────────────────────────────

    def _classify_text(
        self,
        value_text: str,
        entry: Optional[TestEntry],
        extracted_range: str,
    ) -> Tuple[str, str]:
        """Classify qualitative / text-valued results."""
        vt = value_text.strip()
        if _NORMAL_TEXT_VALUES.match(vt):
            return Flag.NORMAL, extracted_range or "Negative"
        if _ABNORMAL_TEXT_VALUES.match(vt):
            return Flag.TEXT_ABNORMAL, extracted_range or ""
        return Flag.UNKNOWN, extracted_range

    # ── Numeric classification ────────────────────────────────────────────────

    def _classify_numeric(
        self,
        value: float,
        entry: Optional[TestEntry],
        extracted_range: str,
        gender: str,
    ) -> Tuple[str, str]:
        """Classify numeric results against reference range."""

        # Determine low/high bounds with priority:
        # 1) extracted range from report  2) DB range  3) None
        low, high, effective_range = self._resolve_range(
            entry, extracted_range, gender
        )

        if low is None and high is None:
            return Flag.UNKNOWN, effective_range

        # Check critical thresholds first
        if entry:
            critical_flag = self._check_critical(
                value, entry.canonical_name.lower()
            )
            if critical_flag:
                return critical_flag, effective_range

        # Normal classification
        too_low  = (low  is not None) and (value < low)
        too_high = (high is not None) and (value > high)

        if too_low:
            return Flag.LOW, effective_range
        if too_high:
            return Flag.HIGH, effective_range
        return Flag.NORMAL, effective_range

    # ── Range resolution ─────────────────────────────────────────────────────

    def _resolve_range(
        self,
        entry: Optional[TestEntry],
        extracted_range: str,
        gender: str,
    ) -> Tuple[Optional[float], Optional[float], str]:
        """
        Try to resolve numeric low/high bounds from:
          1. Extracted range string from the report
          2. Master DB reference range

        Returns (low, high, effective_range_string).
        """

        # Try extracted range first (most lab-specific)
        if extracted_range:
            low, high = _parse_numeric_range(extracted_range)
            if low is not None or high is not None:
                return low, high, extracted_range

        # Fall back to DB range
        if entry and entry.ref_ranges:
            ref: Optional[RefRange] = (
                entry.ref_ranges.get(gender)
                or entry.ref_ranges.get("default")
            )
            if ref and (ref.low is not None or ref.high is not None):
                db_range_str = self._format_range(ref)
                return ref.low, ref.high, db_range_str

        return None, None, extracted_range

    # ── Critical value check ──────────────────────────────────────────────────

    def _check_critical(self, value: float, canonical_lower: str) -> Optional[str]:
        """Return a critical flag if value crosses a panic threshold."""
        thresholds = CRITICAL_THRESHOLDS.get(canonical_lower)
        if not thresholds:
            return None
        crit_low, crit_high = thresholds
        if crit_low is not None and value < crit_low:
            return Flag.CRITICAL_L
        if crit_high is not None and value > crit_high:
            return Flag.CRITICAL_H
        return None

    # ── Formatting helpers ────────────────────────────────────────────────────

    @staticmethod
    def _format_range(ref: RefRange) -> str:
        """Convert a RefRange to a display string like '13.0-17.0'."""
        if ref.text_normal:
            return ref.text_normal
        if ref.low is not None and ref.high is not None:
            # Format cleanly — drop trailing zeros where possible
            lo = int(ref.low) if ref.low == int(ref.low) else ref.low
            hi = int(ref.high) if ref.high == int(ref.high) else ref.high
            return f"{lo}-{hi}"
        if ref.low is not None:
            return f">={ref.low}"
        if ref.high is not None:
            return f"<={ref.high}"
        return ""


# ─────────────────────────────────────────────
#  Module-level singleton
# ─────────────────────────────────────────────

_default_classifier = RangeClassifier()


def classify_result(
    entry: Optional[TestEntry],
    value_numeric: Optional[float],
    value_text: str,
    extracted_range: str = "",
    gender: str = "default",
) -> Tuple[str, str]:
    """
    Module-level shortcut using the default RangeClassifier.

    Returns (flag, effective_range).
    """
    return _default_classifier.classify(
        entry, value_numeric, value_text, extracted_range, gender
    )
