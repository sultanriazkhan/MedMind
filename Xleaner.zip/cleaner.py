"""
cleaner.py
==========
Removes noise / non-test lines from raw OCR/lab-report text.

Strategy:
  1. Line-by-line pass
  2. Pattern-based noise detection (patient metadata, headers, footers, etc.)
  3. Returns a list of candidate lines that *may* contain test results
"""

import re
from typing import List, Tuple
from dataclasses import dataclass


# ─────────────────────────────────────────────
#  Data Structures
# ─────────────────────────────────────────────

@dataclass
class CleanedLine:
    """A single line after cleaning, with provenance metadata."""
    original_line: str          # raw text as extracted from OCR
    normalized_line: str        # lowercased, stripped, OCR-normalized version
    line_number: int            # 1-based index in the original document
    is_noise: bool              # True → this line should be skipped
    noise_reason: str = ""      # why it was flagged as noise (for debugging)


# ─────────────────────────────────────────────
#  Noise Patterns — ordered from most to least specific
# ─────────────────────────────────────────────

# Each tuple: (compiled_regex, human-readable label)
NOISE_PATTERNS: List[Tuple[re.Pattern, str]] = [

    # ── Patient / Demographic metadata ──────────────────────────────────────
    (re.compile(
        r"^(patient\s*(name|id|no|mr\.?|mrn)|name\s*:)",
        re.I), "patient_info"),

    (re.compile(
        r"^(age\s*[:;/]?\s*\d|sex\s*[:;]|gender\s*[:;]|"
        r"(male|female)\s*$|m\s*/\s*f|dob\s*[:;]|date\s+of\s+birth)",
        re.I), "demographics"),

    # ── Doctor / Clinician metadata ──────────────────────────────────────────
    (re.compile(
        r"(dr\.?\s|doctor|physician|consultant|referred\s+by|"
        r"attending|clinician|specialist|mbbs|mrcp|frcp|fcps|md\s|"
        r"signature|stamp|seal)",
        re.I), "doctor_info"),

    # ── Date / Time metadata ─────────────────────────────────────────────────
    (re.compile(
        r"(collected\s*(on|date|at)|sample\s*(collected|date|time|received)|"
        r"report\s*(date|time|on|generated)|tested\s*(on|date)|"
        r"received\s*(on|date)|reported\s*(on|date|by)|"
        r"date\s*of\s*(collection|report|test)|"
        r"\d{1,2}[\-/\.]\d{1,2}[\-/\.]\d{2,4}\s+\d{1,2}:\d{2})",
        re.I), "date_time"),

    # ── Lab / Address / Contact metadata ─────────────────────────────────────
    (re.compile(
        r"(lab(oratory)?\s*(name|address|no|code|ref)|"
        r"hospital|clinic|diagnostic|centre|center|"
        r"address|ph(one)?\.?\s*[:;#]?\s*(\+|0)\d|"
        r"tel\.|fax|email|website|www\.|http|karachi|lahore|islamabad|"
        r"rawalpindi|peshawar|quetta|multan|faisalabad|sialkot)",
        re.I), "lab_address"),

    # ── Invoice / Financial metadata ─────────────────────────────────────────
    (re.compile(
        r"(invoice|receipt|bill|amount|rs\.?\s*\d|fee|payment|"
        r"discount|charges|tax|total amount)",
        re.I), "financial"),

    # ── Barcode / ID numbers ─────────────────────────────────────────────────
    (re.compile(
        r"(barcode|acc(ession)?\s*(no|#)|lab\s*id|"
        r"sample\s*(id|no|#)|order\s*(id|no|#)|"
        r"ref(erence)?\s*(no|#|id)|reg\s*(no|#|id))",
        re.I), "barcode_id"),

    # ── Pagination / Document metadata ───────────────────────────────────────
    (re.compile(
        r"(page\s+\d+\s+(of|/)\s+\d+|"
        r"^\s*\d+\s+of\s+\d+\s*$|"
        r"continued\s+on\s+(next|page)|"
        r"end\s+of\s+report|"
        r"report\s+end|"
        r"printed\s+(on|by|at))",
        re.I), "pagination"),

    # ── Disclaimer / Legal boilerplate ───────────────────────────────────────
    (re.compile(
        r"(this\s+report\s+is\s+|results?\s+are\s+for\s+|"
        r"for\s+clinical\s+use|not\s+valid\s+without|"
        r"disclaimer|confidential|all\s+rights\s+reserved|"
        r"interpretation\s+of\s+results|"
        r"normal\s+range\s+may\s+vary|"
        r"consult\s+your\s+physician)",
        re.I), "disclaimer"),

    # ── Section headers (all-caps or decorative lines) ─────────────────────
    (re.compile(
        r"(^-{3,}$|^={3,}$|^\*{3,}$|^_{3,}$|"
        r"^[A-Z\s]{10,}$|"                     # ALL CAPS header-like lines
        r"^(test\s+name|result|unit|ref(erence)?\s+(range|values?)|"
        r"interpretation|method|remarks?|"
        r"analyte|component|parameter)\s*$)",
        re.I), "table_header"),

    # ── Printed-by / verified-by ──────────────────────────────────────────────
    (re.compile(
        r"(verified\s+by|checked\s+by|authorized\s+by|"
        r"pathologist|microbiologist|biochemist)",
        re.I), "signatory"),

    # ── Empty / whitespace-only / separator lines ─────────────────────────────
    (re.compile(r"^\s*$"), "empty_line"),

    # ── Lines with no alphanumeric content ────────────────────────────────────
    (re.compile(r"^[^a-zA-Z0-9]*$"), "no_alphanum"),

    # ── Very short lines unlikely to contain results (< 3 chars) ─────────────
    (re.compile(r"^.{0,2}$"), "too_short"),
]


# ─────────────────────────────────────────────
#  OCR Normalization Helpers
# ─────────────────────────────────────────────

# Common OCR substitution errors in lab reports
OCR_FIXES: List[Tuple[str, str]] = [
    # Digit / letter confusion
    (r"\b0(?=[a-zA-Z])", "O"),   # 0B → OB  (unlikely in lab context, skip)
    (r"(?<=[a-zA-Z])0\b", "O"),  # HB0 → HBO
    (r"\bl\b", "1"),              # lone 'l' as digit (rare)
    # Punctuation normalization
    (r"[\u2013\u2014]", "-"),     # em/en dash → hyphen
    (r"\u00b5", "u"),             # μ → u  (e.g., μg → ug)
    (r"µ", "u"),
    (r"\u00b2", "2"),             # superscript 2
    (r"\u00b3", "3"),             # superscript 3
    (r"\u00b9", "1"),             # superscript 1
    (r"\u00b0", ""),              # degree symbol (remove)
    (r"\s{2,}", " "),             # multiple spaces → single space
    (r"\.{2,}", "."),             # multiple dots → single dot
]

_OCR_COMPILED = [(re.compile(p), r) for p, r in OCR_FIXES]


def normalize_ocr(text: str) -> str:
    """Apply OCR correction substitutions to a line of text."""
    for pattern, replacement in _OCR_COMPILED:
        text = pattern.sub(replacement, text)
    return text.strip()


# ─────────────────────────────────────────────
#  Main Cleaning Logic
# ─────────────────────────────────────────────

class LabReportCleaner:
    """
    Processes raw OCR text from a lab report and returns:
      - cleaned_lines : lines that survived noise filtering (candidate test results)
      - noise_lines   : lines that were filtered out (for debugging / audit)
    """

    def __init__(self, custom_noise_patterns: List[Tuple[re.Pattern, str]] | None = None):
        """
        Args:
            custom_noise_patterns: Optional extra (regex, label) pairs to extend
                                   the built-in NOISE_PATTERNS list.
        """
        self.patterns = NOISE_PATTERNS.copy()
        if custom_noise_patterns:
            self.patterns.extend(custom_noise_patterns)

    # ── Public API ────────────────────────────────────────────────────────────

    def clean(self, raw_text: str) -> Tuple[List[CleanedLine], List[CleanedLine]]:
        """
        Clean raw OCR text.

        Args:
            raw_text: Multi-line string from OCR output.

        Returns:
            (candidate_lines, noise_lines)
            Both are lists of CleanedLine dataclass instances.
        """
        candidate_lines: List[CleanedLine] = []
        noise_lines: List[CleanedLine] = []

        for idx, raw_line in enumerate(raw_text.splitlines(), start=1):
            ocr_normalized = normalize_ocr(raw_line)
            lower_line = ocr_normalized.lower()

            is_noise, reason = self._classify_line(lower_line)

            cleaned = CleanedLine(
                original_line=raw_line,
                normalized_line=ocr_normalized,
                line_number=idx,
                is_noise=is_noise,
                noise_reason=reason,
            )

            if is_noise:
                noise_lines.append(cleaned)
            else:
                candidate_lines.append(cleaned)

        return candidate_lines, noise_lines

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _classify_line(self, lower_line: str) -> Tuple[bool, str]:
        """
        Return (True, reason) if the line is noise, else (False, "").

        Uses the ordered NOISE_PATTERNS list — first match wins.
        """
        for pattern, label in self.patterns:
            if pattern.search(lower_line):
                return True, label
        return False, ""

    # ── Utility ───────────────────────────────────────────────────────────────

    @staticmethod
    def get_candidate_text(candidate_lines: List[CleanedLine]) -> str:
        """Reconstruct plain text from candidate lines (for debugging/logging)."""
        return "\n".join(cl.normalized_line for cl in candidate_lines)
