"""
main.py
=======
Orchestrator for the Medical Lab Report Cleaning Module.

Pipeline:
  Raw OCR Text
      │
      ▼ cleaner.py        → remove noise lines
  Candidate Lines
      │
      ▼ parser.py         → extract (name_token, value, unit, ref_range)
  Parsed Lines (structured)
      │
      ▼ matcher.py        → map name_token → canonical TestEntry
  Matched Results
      │
      ▼ range_classifier.py  → determine flag (High/Low/Normal/Unknown)
  Final JSON Output

Usage:
    python main.py                        # runs built-in demo
    python main.py --file report.txt      # process a file
    python main.py --text "Hb 11.2 g/dL 13-17"   # single-line test
"""

import json
import sys
import argparse
from dataclasses import dataclass, asdict
from typing import List, Optional

from cleaner import LabReportCleaner
from parser import LineParser
from matcher import TestMatcher
from range_classifier import RangeClassifier


# ─────────────────────────────────────────────
#  Output Data Model
# ─────────────────────────────────────────────

@dataclass
class LabResult:
    """
    One cleaned, structured lab test result.
    This maps directly to the required JSON output format.
    """
    test: str                       # human-readable name (canonical or detected)
    canonical_name: str             # canonical name from master DB
    loinc_id: Optional[str]        # LOINC code (None if unknown)
    detected_from_text: str         # the alias/token that triggered the match
    value: object                   # numeric (float/int) or string
    unit: str                       # measurement unit
    reference_range: str            # reference range used for classification
    flag: str                       # High | Low | Normal | Critical High | Critical Low | Unknown
    confidence_score: float         # match confidence 0.0 – 1.0
    category: str                   # CBC, Liver, Kidney, etc.
    raw_line: str                   # the original OCR line
    match_type: str                 # exact | dotstrip | loinc | fuzzy | none


# ─────────────────────────────────────────────
#  Main Pipeline Class
# ─────────────────────────────────────────────

class LabReportCleaner_Pipeline:
    """
    End-to-end pipeline that converts raw OCR text → clean structured JSON.

    Args:
        min_confidence : Minimum matcher confidence to accept a result (0–1)
        gender         : Patient gender for reference range selection
                         ("male" | "female" | "child" | "default")
        verbose        : If True, print debug info for each line processed
    """

    def __init__(
        self,
        min_confidence: float = 0.50,
        gender: str = "default",
        verbose: bool = False,
    ):
        self.min_confidence = min_confidence
        self.gender = gender
        self.verbose = verbose

        # Instantiate sub-modules
        self._cleaner    = LabReportCleaner()
        self._parser     = LineParser()
        self._matcher    = TestMatcher(min_confidence=min_confidence)
        self._classifier = RangeClassifier()

    # ── Public API ────────────────────────────────────────────────────────────

    def process(self, raw_text: str) -> List[LabResult]:
        """
        Full pipeline: raw text → list of LabResult objects.

        Args:
            raw_text: Multi-line OCR output from a lab report.

        Returns:
            List of LabResult objects (one per successfully identified test).
        """
        results: List[LabResult] = []

        # ── Step 1: Noise Filtering ────────────────────────────────────────────
        candidate_lines, noise_lines = self._cleaner.clean(raw_text)

        if self.verbose:
            print(f"\n[Cleaner] {len(candidate_lines)} candidate lines, "
                  f"{len(noise_lines)} noise lines filtered.\n")

        # ── Step 2: Parse + Match + Classify each line ────────────────────────
        for cl in candidate_lines:
            result = self._process_line(cl.normalized_line, cl.original_line)
            if result is not None:
                results.append(result)

        # ── Step 3: De-duplicate (keep highest-confidence per canonical name) ──
        results = self._deduplicate(results)

        return results

    def to_json(self, results: List[LabResult], indent: int = 2) -> str:
        """Serialize results to formatted JSON string."""
        output = []
        for r in results:
            d = asdict(r)
            # Clean up None values for cleaner JSON
            d = {k: v for k, v in d.items() if v is not None or k == "loinc_id"}
            # Convert value to int if it's a whole number float
            if isinstance(d.get("value"), float) and d["value"].is_integer():
                if d["value"] > 100:    # likely a count (WBC, Platelets etc.)
                    d["value"] = int(d["value"])
            output.append(d)
        return json.dumps(output, indent=indent, ensure_ascii=False)

    # ── Internal ──────────────────────────────────────────────────────────────

    def _process_line(self, norm_line: str, raw_line: str) -> Optional[LabResult]:
        """
        Process a single candidate line through parse → match → classify.
        Returns None if no valid test result is found.
        """

        # Parse: extract token, value, unit, range
        parsed = self._parser.parse(norm_line)

        if not parsed.parse_success:
            if self.verbose:
                print(f"  [Parser] SKIP (parse failed): {norm_line!r}")
            return None

        # Match: identify canonical test from name token
        match_result = self._matcher.match(parsed.test_name_token)

        if match_result.entry is None:
            if self.verbose:
                print(f"  [Matcher] SKIP (no match for '{parsed.test_name_token}'): "
                      f"{norm_line!r}")
            return None

        entry = match_result.entry

        if self.verbose:
            print(f"  [Matched] '{parsed.test_name_token}' → "
                  f"'{entry.canonical_name}' "
                  f"(confidence={match_result.confidence:.2f}, "
                  f"type={match_result.match_type})")

        # Classify: determine flag
        flag, effective_range = self._classifier.classify(
            entry=entry,
            value_numeric=parsed.value_numeric,
            value_text=parsed.value_raw,
            extracted_range=parsed.reference_range,
            gender=self.gender,
        )

        # Determine display value: prefer int for large counts
        display_value: object = parsed.value_numeric
        if display_value is None:
            display_value = parsed.value_raw     # text result

        # Prefer extracted unit; fall back to first DB unit if missing
        unit = parsed.unit
        if not unit and entry.common_units:
            unit = entry.common_units[0]

        return LabResult(
            test=entry.canonical_name,
            canonical_name=entry.canonical_name,
            loinc_id=entry.loinc_id,
            detected_from_text=parsed.test_name_token,
            value=display_value,
            unit=unit,
            reference_range=effective_range or parsed.reference_range,
            flag=flag,
            confidence_score=round(match_result.confidence, 3),
            category=entry.category,
            raw_line=raw_line,
            match_type=match_result.match_type,
        )

    def _deduplicate(self, results: List[LabResult]) -> List[LabResult]:
        """
        If the same canonical test appears more than once,
        keep only the entry with the highest confidence score.
        """
        seen: dict[str, LabResult] = {}
        for r in results:
            key = r.canonical_name
            if key not in seen or r.confidence_score > seen[key].confidence_score:
                seen[key] = r
        return list(seen.values())


# ─────────────────────────────────────────────
#  Sample OCR text snippets for demonstration
# ─────────────────────────────────────────────

SAMPLE_OCR_TEXTS = {

    "pakistani_lab_typical": """
Patient Name: Ali Khan
Age: 24 Years
Gender: Male
Date of Collection: 12/03/2024
Report Date: 13/03/2024

Lab: City Diagnostics, Karachi
Dr. Ahmed Siddiqui MBBS, FCPS
Sample ID: CK-2024-09876

--------------------------------
COMPLETE BLOOD COUNT (CBC)
--------------------------------
Test Name         Result   Unit       Reference Range
Hb                11.2     g/dL       13.0 - 17.0
WBC               14000    /uL        4000 - 11000
Platelets         180      10^3/uL    150 - 450
HCT               35.1     %          40 - 54
MCV               75.4     fL         80 - 100
MCH               22.3     pg         27 - 33
MCHC              31.2     g/dL       32 - 36
Neutrophils       72       %          40 - 75
Lymphocytes       21       %          20 - 45

--------------------------------
KIDNEY FUNCTION TESTS
--------------------------------
Urea              42       mg/dL      15 - 45
Creatinine        1.4      mg/dL      0.7 - 1.3
Sodium            138      mEq/L      136 - 145
Potassium         3.8      mEq/L      3.5 - 5.0

--------------------------------
LIVER FUNCTION TESTS
--------------------------------
ALT/SGPT          65       U/L        7 - 56
AST/SGOT          38       U/L        10 - 40
ALP               110      U/L        44 - 147
Bilirubin Total   1.1      mg/dL      0.2 - 1.2
Albumin           3.9      g/dL       3.5 - 5.0

--------------------------------
LIPID PROFILE
--------------------------------
Total Cholesterol  215     mg/dL      < 200
HDL Cholesterol    38      mg/dL      40 - 60
LDL Cholesterol    142     mg/dL      < 100
Triglycerides      175     mg/dL      < 150

--------------------------------
THYROID
--------------------------------
TSH               5.8      mIU/L      0.4 - 4.0
Free T3           2.9      pg/mL      2.3 - 4.2
Free T4           0.95     ng/dL      0.8 - 1.8

--------------------------------
DIABETES
--------------------------------
Glucose (Fasting)  106     mg/dL      70 - 99
HbA1c              6.2     %          < 5.7

Verified by: Dr. Sara Khan, Pathologist
End of Report
Page 1 of 1
""",

    "ocr_noisy_abbreviated": """
REF# LH-2024-00321
Patient: Fatima Malik     Age: 35F
Collected: 14-Mar-2024    Phone: 0300-1234567
Invoice No: INV-8812

                HAEMATOLOGY
Hgb              9.8    gm/dL       12-16       Low
TLC              7200   /cumm       4000-11000   Normal
PCV              29.0   %           36-48        Low
PLT              92     x10^3/uL    150-450      Low
ESR              48     mm/1hr      0-20         High
S.G.P.T          52     U/L         7-45
S.G.O.T          29     U/L         9-32
ALP              88     U/L         44-147
S.Bilirubin(T)   0.8    mg/dL       0.2-1.2
Serum Albumin    3.2    g/dL        3.5-5.0      Low

       VITAMINS & MINERALS
Vit. D (25-OH)   12.5   ng/mL       30-100       Low
Vit B12          185    pg/mL       200-900       Low
Ferritin         6.2    ng/mL       10-120        Low
Serum Iron       42     ug/dL       50-170        Low
TIBC             390    ug/dL       250-370       High

Disclaimer: Results should be interpreted in clinical context.
Lab Address: Plot 22, Block 5, Gulshan-e-Iqbal, Karachi
All rights reserved. Confidential report.
""",

    "thyroid_diabetes_panel": """
THYROID FUNCTION TESTS - IMMUNOASSAY PANEL
Patient ID: P-1002
Barcode: 220394857

T.S.H           0.12    uIU/mL      0.4-4.0
F.T3            5.8     pg/mL       2.3-4.2
F.T4            2.1     ng/dL       0.8-1.8
Anti-TPO        450     IU/mL       0-34

DIABETES PANEL
Fasting Blood Sugar  118   mg/dL   70-99
HbA1c%              7.2   %        < 5.7
Fasting Insulin     28    uIU/mL   2-25

CARDIAC MARKERS
CRP              18.5   mg/L      0-5
D-Dimer          1.2    ug/mL     0-0.5
Troponin I       0.08   ng/mL     0-0.04

Page 1 of 1 | Reported by: Lab Management System
""",
}


# ─────────────────────────────────────────────
#  CLI Entry Point
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Medical Lab Report Cleaning Module — converts raw OCR text to structured JSON"
    )
    parser.add_argument(
        "--file",   type=str, default=None,
        help="Path to a .txt file containing raw OCR output"
    )
    parser.add_argument(
        "--text",   type=str, default=None,
        help="Raw OCR text passed directly as a string"
    )
    parser.add_argument(
        "--gender", type=str, default="default",
        choices=["male", "female", "child", "default"],
        help="Patient gender for reference range matching"
    )
    parser.add_argument(
        "--confidence", type=float, default=0.50,
        help="Minimum confidence threshold (0.0-1.0) to accept a match"
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Print debug information per line"
    )
    parser.add_argument(
        "--demo", type=str, default=None,
        choices=list(SAMPLE_OCR_TEXTS.keys()),
        help="Run one of the built-in demo samples"
    )
    parser.add_argument(
        "--demo-all", action="store_true",
        help="Run all built-in demo samples"
    )

    args = parser.parse_args()

    pipeline = LabReportCleaner_Pipeline(
        min_confidence=args.confidence,
        gender=args.gender,
        verbose=args.verbose,
    )

    # ── Determine input ───────────────────────────────────────────────────────
    if args.file:
        with open(args.file, "r", encoding="utf-8") as f:
            raw_text = f.read()
        _run_single(pipeline, raw_text, label=args.file)

    elif args.text:
        _run_single(pipeline, args.text, label="<command-line text>")

    elif args.demo:
        raw_text = SAMPLE_OCR_TEXTS[args.demo]
        _run_single(pipeline, raw_text, label=args.demo)

    elif args.demo_all:
        for name, raw_text in SAMPLE_OCR_TEXTS.items():
            _run_single(pipeline, raw_text, label=name)

    else:
        # Default: run all demos if called with no arguments
        print("=" * 70)
        print("  Medical Lab Report Cleaning Module — Demo Run")
        print("=" * 70)
        for name, raw_text in SAMPLE_OCR_TEXTS.items():
            _run_single(pipeline, raw_text, label=name)

    return 0


def _run_single(pipeline: LabReportCleaner_Pipeline, raw_text: str, label: str):
    """Helper: process one text blob and pretty-print results."""
    print(f"\n{'─'*70}")
    print(f"  Sample: {label}")
    print(f"{'─'*70}\n")
    print("Input OCR Text:")
    print(raw_text[:500] + ("..." if len(raw_text) > 500 else ""))
    print(f"\n{'─'*70}")

    results = pipeline.process(raw_text)
    json_output = pipeline.to_json(results)

    print(f"Extracted {len(results)} test(s):\n")
    print(json_output)

    # Quick summary table
    print(f"\n{'─'*70}")
    print(f"{'Test':<30} {'Value':<10} {'Unit':<12} {'Flag':<14} {'Conf':<6}")
    print(f"{'─'*30} {'─'*10} {'─'*12} {'─'*14} {'─'*6}")
    for r in results:
        val_str = str(r.value) if r.value is not None else "—"
        flag_str = r.flag.value if hasattr(r.flag, "value") else str(r.flag)
        print(f"{r.canonical_name:<30} {val_str:<10} {r.unit:<12} {flag_str:<14} {r.confidence_score:.2f}")
    print()


# ─────────────────────────────────────────────
#  Guard
# ─────────────────────────────────────────────

if __name__ == "__main__":
    sys.exit(main())
